//
//  ViewController.swift
//  localizationDemo
//
//  Created by Drish on 15/06/20.
//  Copyright © 2020 Drish. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var lblLocalization: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        lblLocalization.text = NSLocalizedString("Welcome", comment: "")
    }


}

